<?php

  include_once('../monket-cal-config.php');
  include_once('../../monket-cal-source/monket-cal-update.php');

  doUpdate();

?>
